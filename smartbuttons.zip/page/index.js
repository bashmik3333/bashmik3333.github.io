function sendHttp() {
  fetch({
    url: "http://192.168.1.100:8123/api/webhook/-AkduMaUgpj2ova4bCX-i9Qa2",
    method: "POST",
    header: { "Content-Type": "application/json" },
    body: JSON.stringify({ source: "zepp_balance2" })
  })
  .then(() => hmUI.showToast({ text: "Свет включен" }))
  .catch(() => hmUI.showToast({ text: "Ошибка HTTP" }));
}

function sendTasker() {
  fetch({
    // Этот URL должен вести на AutoRemote/Join/Tasker HTTP-сервер на телефоне
    url: "http://127.0.0.1:1817/?message=mute",
    method: "GET",
  })
  .then(() => hmUI.showToast({ text: "Mute OK" }))
  .catch(() => hmUI.showToast({ text: "Ошибка Tasker" }));
}

Page({
  build() {
    const { width } = hmSetting.getDeviceInfo();
    let y = 40;

    function addButton(text, func) {
      hmUI.createWidget(hmUI.widget.BUTTON, {
        x: 20, y, w: width - 40, h: 80,
        text,
        text_size: 24,
        normal_color: 0x1E90FF,
        press_color: 0x2763c4,
        radius: 20,
        click_func: func
      });
      y += 100;
    }

    addButton("Mute", sendTasker);
    addButton("ВКЛ СВЕТ", sendHttp);
  }
});
