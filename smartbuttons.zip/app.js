App({
  onCreate() {
    console.log("Smart Buttons app created");
  },
  onDestroy() {
    console.log("Smart Buttons app destroyed");
  }
});
